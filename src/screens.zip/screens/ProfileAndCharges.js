import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,

} from 'react-native';


export default function ProfileAndCharges({navigation}) {
  const gotoupdatepassword = () =>{
    navigation.navigate('UpdatePassword');
  }

  const gotoupdateprofile = () =>{
    navigation.navigate('UpdateProfile');
  }
  const gotoupdatecharges = () =>{
    navigation.navigate('UpdateCharges');
  }
  return (
    <View style={styles.container}>
         <Text style={styles.head}>Profile and Charges</Text>

            <TouchableOpacity style={styles.content} onPress={gotoupdatepassword} >
                <Text style={styles.txt}> Update Password</Text>
            </TouchableOpacity>


            <TouchableOpacity style={styles.content} onPress={gotoupdateprofile}>
                <Text style={styles.txt}>Update Profile</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.content}onPress={gotoupdatecharges}>
                <Text style={styles.txt}>Update Charges</Text>
            </TouchableOpacity>

            

          
     </View>
  );
}

const styles = StyleSheet.create({
  head:{
        backgroundColor: 'coral',
        padding: 20,
        fontSize: 20,
        textAlign:'center',
        marginBottom:150,
    },

    container:{
      flex: 1,
      backgroundColor: '#fff',
      
      },
  
      content:{
        alignItems: "center",
        backgroundColor: "coral",
        padding: 10,
        height:50,
        marginBottom:30,
        marginLeft:20,
        borderRadius:10,
        width:330,
      
  
      },
  
      txt:{
        fontFamily:'verdana',
        fontSize:18,
        color:'#fff',
        fontWeight:'bold',
        
        
      },
});
