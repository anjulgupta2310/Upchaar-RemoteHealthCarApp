import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  Button,

} from 'react-native';


export default function App() {
  return (
    <View style={styles.container}>
         <Text style={styles.head}>Online Charges</Text>

              <Text style={styles.line}>Specialisation</Text>
              <TextInput
              keyboardType='default'
              placeholder='Cardiologist'
              style={styles.input}
              />

                <Text style={styles.line}>Current Charges</Text>
              <TextInput
              keyboardType='numeric'
              placeholder='Rs. 800'
              style={styles.input}
              />

            <Button  title='SUBMIT'/>

            

          
     </View>
  );
}

const styles = StyleSheet.create({
  head:{
        backgroundColor: 'coral',
        padding: 20,
        fontSize: 20,
        textAlign:'center',
        marginBottom:150,
    },

    container:{
      flex: 1,
      backgroundColor: '#fff',
      
      },
  
      line:{
        fontFamily:'verdana',
        fontSize:20,
        marginBottom:10,
        paddingLeft:20,
      },
      
      input:{
          
          height: 50,
          borderColor: 'coral',
          borderWidth: 1, 
          marginBottom:30,
          width:400,
          borderRadius:5,
  
      },
    
});
