import React,{Component} from 'react';
import {StyleSheet, View, Text, TextInput, Button,Alert} from 'react-native';
import {db} from '../config';

//  function Portal({navigation}) {

//   const gotoportal = () =>{
//     navigation.navigate('Portal');
//   }
// }
export default class Login extends Component {
  state = {
    license: '',
    password: '',
  };


  checkitem(){
    var key=this.state.license;
    const myitems=db.ref(`items/${key}`);
    myitems.on("value",datasnap=>{
      const t=datasnap.val();
      var p=this.state.password;
      var flag=0;
      var m = p.localeCompare(t.password);
      if(m==0)
      {
        flag=1;
        this.props.navigation.navigate('Portal');
      }
      if(flag==0)
      {
        Alert.alert("Invalid data");
      }
    })
    
  }


  // const gotosignup = () => {
  //   navigation.navigate('Signup');
  // };
  
  // const gotoportal = () => {
  //   navigation.navigate('Portal');
  // };
  
  
  
  render()
  {
  return (
    <View style={styles.container}>
      <Text style={styles.head}>Login to Proceed</Text>

      <View style="styles.content">
        <Text style={styles.line}>License No.</Text>
        <TextInput
          keyboardType="numeric"
          style={styles.input}
          placeholder="33408256"
          onChangeText={(license) => this.setState({license})}
        />

        <Text style={styles.line}>Password</Text>
        <TextInput
          style={styles.input}
          placeholder="xyz_1998"
          onChangeText={(password) => this.setState({password})}
        />

        <Button style={styles.buttonline} title="SUBMIT" onPress={() => this.checkitem()} />

        <Button style={styles.buttonline} title="SIGNUP" onPress = {()=>this.props.navigation.navigate('Signup')} />
      </View>
    </View>
  );
}
}

const styles = StyleSheet.create({
  head: {
    backgroundColor: 'coral',
    padding: 20,
    fontSize: 20,
    textAlign: 'center',
    marginBottom: 80,
  },

  container: {
    flex: 1,
    backgroundColor: '#fff',
  },

  content: {
    padding: 50,
  },

  buttonline: {
    padding: 20,
    color: 'coral',
  },

  line: {
    fontFamily: 'verdana',
    fontSize: 20,
    marginBottom: 10,
    paddingLeft: 20,
  },
  input: {
    height: 50,
    borderColor: 'coral',
    borderWidth: 1,
    marginBottom: 30,
  },
});
