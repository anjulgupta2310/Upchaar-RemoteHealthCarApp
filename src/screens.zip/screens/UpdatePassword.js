import React,{Component} from 'react';
import {
  StyleSheet,
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  Button,
  Alert,
} from 'react-native';


export default class UpdatePassword extends Component {
  
  render() {
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView>
          <Text style={styles.head}>Update Password</Text>
          <Text style={styles.line}>Enter Old Password</Text>
          <TextInput
            keyboardType="numeric"
            style={styles.input}
            // value={this.state.license}
            // onChangeText={(license) => this.setState({license})}
          />

          <Text style={styles.line}>Enter new Password</Text>
          <TextInput
            keyboardType="numeric"
            style={styles.input}
            // value={this.state.email}
            // onChangeText={(email) => this.setState({email})}
          />

          <Text style={styles.line}>Confirm new Password</Text>
          <TextInput
            keyboardType="numeric"
            style={styles.input}
            // value={this.state.phone}
            // onChangeText={(phone) => this.setState({phone})}
          />

         

          <Button title="SUBMIT"  />
        </ScrollView>
      </SafeAreaView>
    );
  }
}


const styles = StyleSheet.create({
  head: {
    backgroundColor: 'coral',
    padding: 20,
    fontSize: 20,
    textAlign: 'center',
    marginBottom: 80,
  },

  container: {
    flex: 1,
    backgroundColor: '#fff',
  },

  content: {
    padding: 50,
  },

  line: {
    fontFamily: 'verdana',
    fontSize: 20,
    marginBottom: 10,
    paddingLeft: 20,
  },
  input: {
    height: 50,
    borderColor: 'coral',
    borderWidth: 1,
    marginBottom: 30,
    width: 400,
    borderRadius: 5,
  },
});
